
from collections import deque

# Create an empty graph
def create_graph():
    return {}

# Add a vertex to the graph
def add_vertex(graph, vertex):
    if vertex not in graph:
        graph[vertex] = []

# Add an edge (undirected)
def add_edge(graph, v1, v2):
    if v1 not in graph:
        add_vertex(graph, v1)
    if v2 not in graph:
        add_vertex(graph, v2)
    graph[v1].append(v2)
    graph[v2].append(v1)

# Depth-First Search
def dfs(graph, start, visited=None):
    if visited is None:
        visited = set()
    visited.add(start)
    print(start, end=" ")
    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)

# Breadth-First Search
def bfs(graph, start):
    visited = set()
    queue = deque([start])
    visited.add(start)
    while queue:
        vertex = queue.popleft()
        print(vertex, end=" ")
        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
