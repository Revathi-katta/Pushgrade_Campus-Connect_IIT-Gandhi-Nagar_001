
# Queue using Array

def create_queue_array():
    return {"items": []}

def enqueue_array(queue, value):
    queue["items"].append(value)

def dequeue_array(queue):
    if queue["items"]:
        return queue["items"].pop(0)  # Remove from front
    return None  # Queue underflow

def front_array(queue):
    if queue["items"]:
        return queue["items"][0]
    return None


# Queue using Linked List

def create_node(value):
    return {"data": value, "next": None}

def create_queue_linked():
    return {"front": None, "rear": None}

def enqueue_linked(queue, value):
    new_node = create_node(value)
    if queue["rear"] is None:
        queue["front"] = queue["rear"] = new_node
    else:
        queue["rear"]["next"] = new_node
        queue["rear"] = new_node

def dequeue_linked(queue):
    if queue["front"] is None:
        return None  # Queue underflow
    value = queue["front"]["data"]
    queue["front"] = queue["front"]["next"]
    if queue["front"] is None:
        queue["rear"] = None  # Queue became empty
    return value

def front_linked(queue):
    if queue["front"]:
        return queue["front"]["data"]
    return None
