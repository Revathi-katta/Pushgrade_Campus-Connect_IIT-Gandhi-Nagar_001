
# Singly Linked List Implementation

def create_node(value):
    return {"data": value, "next": None}

def create_singly_linked_list():
    return {"head": None}

def insert_singly(ll, value):
    new_node = create_node(value)
    if ll["head"] is None:
        ll["head"] = new_node
    else:
        current = ll["head"]
        while current["next"]:
            current = current["next"]
        current["next"] = new_node

def delete_singly(ll, value):
    current = ll["head"]
    prev = None
    while current:
        if current["data"] == value:
            if prev:
                prev["next"] = current["next"]
            else:
                ll["head"] = current["next"]
            return True
        prev = current
        current = current["next"]
    return False

def traverse_singly(ll):
    result = []
    current = ll["head"]
    while current:
        result.append(current["data"])
        current = current["next"]
    return result

# Doubly Linked List Implementation

def create_dll_node(value):
    return {"data": value, "prev": None, "next": None}

def create_doubly_linked_list():
    return {"head": None}

def insert_doubly(dll, value):
    new_node = create_dll_node(value)
    if dll["head"] is None:
        dll["head"] = new_node
    else:
        current = dll["head"]
        while current["next"]:
            current = current["next"]
        current["next"] = new_node
        new_node["prev"] = current

def delete_doubly(dll, value):
    current = dll["head"]
    while current:
        if current["data"] == value:
            if current["prev"]:
                current["prev"]["next"] = current["next"]
            else:
                dll["head"] = current["next"]
            if current["next"]:
                current["next"]["prev"] = current["prev"]
            return True
        current = current["next"]
    return False

def traverse_doubly(dll):
    result = []
    current = dll["head"]
    while current:
        result.append(current["data"])
        current = current["next"]
    return result
