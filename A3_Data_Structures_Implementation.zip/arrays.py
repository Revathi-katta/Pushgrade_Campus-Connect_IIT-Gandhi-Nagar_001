
def create_array():
    return {
        "capacity": 1,
        "size": 0,
        "array": [None]
    }

def resize(arr):
    arr["capacity"] *= 2
    new_array = [None] * arr["capacity"]
    for i in range(arr["size"]):
        new_array[i] = arr["array"][i]
    arr["array"] = new_array

def insert(arr, value):
    if arr["size"] == arr["capacity"]:
        resize(arr)
    arr["array"][arr["size"]] = value
    arr["size"] += 1

def delete(arr, index):
    if 0 <= index < arr["size"]:
        for i in range(index, arr["size"] - 1):
            arr["array"][i] = arr["array"][i + 1]
        arr["array"][arr["size"] - 1] = None
        arr["size"] -= 1

def get(arr, index):
    if 0 <= index < arr["size"]:
        return arr["array"][index]
    raise IndexError("Index out of bounds")
