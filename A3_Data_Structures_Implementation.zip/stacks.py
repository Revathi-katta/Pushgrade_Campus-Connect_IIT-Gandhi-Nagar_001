
# Stack using Array

def create_stack_array():
    return {"items": []}

def push_array(stack, value):
    stack["items"].append(value)

def pop_array(stack):
    if stack["items"]:
        return stack["items"].pop()
    return None  # Stack underflow

def peek_array(stack):
    if stack["items"]:
        return stack["items"][-1]
    return None

# Stack using Linked List

def create_node(value):
    return {"data": value, "next": None}

def create_stack_linked():
    return {"top": None}

def push_linked(stack, value):
    new_node = create_node(value)
    new_node["next"] = stack["top"]
    stack["top"] = new_node

def pop_linked(stack):
    if stack["top"] is None:
        return None  # Stack underflow
    value = stack["top"]["data"]
    stack["top"] = stack["top"]["next"]
    return value

def peek_linked(stack):
    if stack["top"]:
        return stack["top"]["data"]
    return None
