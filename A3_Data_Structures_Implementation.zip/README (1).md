
# Data Structures Implementation

## Files:
- arrays.py
- linked_list.py
- stack_array.py
- queue_array.py
- binary_tree.py
- graph.py
- test.py
- A3_Data_Structures_Implementation.ipynb
- README.md

## How to run:
Use `python test.py` to run all examples.  
Each individual file defines one data structure and its operations.  
You can also open the notebook `A3_Data_Structures_Implementation.ipynb` to see all code and outputs.

## Functions (per file):

### arrays.py
- insert(val): Adds element to array.
- delete(index): Deletes element at index.
- get(index): Returns value at index.

### linked_list.py
- insert_singly(val): Inserts into singly linked list.
- delete_singly(val): Deletes from singly linked list.
- insert_doubly(val): Inserts into doubly linked list.
- delete_doubly(val): Deletes from doubly linked list.

### stack_array.py
- push(val): Push element on stack.
- pop(): Remove top element.
- peek(): View top element.

### queue_array.py
- enqueue(val): Adds to queue.
- dequeue(): Removes from queue.
- front(): Returns front element.

### binary_tree.py
- insert(val): Adds node to binary tree.
- delete(val): Deletes a node.
- traverse_in_order(): In-order traversal.
- traverse_pre_order(): Pre-order traversal.
- traverse_post_order(): Post-order traversal.

### graph.py
- add_vertex(v): Adds vertex.
- add_edge(u, v): Adds edge.
- dfs(start): Depth-first search.
- bfs(start): Breadth-first search.
