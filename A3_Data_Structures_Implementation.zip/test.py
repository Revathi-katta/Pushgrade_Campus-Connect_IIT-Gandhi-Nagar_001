

    import arrays as arr_mod

    arr = arr_mod.create_array()
    arr_mod.insert(arr, 10)
    arr_mod.insert(arr, 20)
    print(arr_mod.get(arr, 0))  # Output: 10
    arr_mod.delete(arr, 0)
    print(arr_mod.get(arr, 0))  # Output: 20


    import linked_lists as ll

    # Singly Linked List
    sll = ll.create_singly_linked_list()
    ll.insert_singly(sll, 10)
    ll.insert_singly(sll, 20)
    ll.insert_singly(sll, 30)
    print("Traverse Singly after inserting nodes:", ll.traverse_singly(sll))  # Output: [10, 20, 30]
    ll.delete_singly(sll, 20)
    print("After delete:", ll.traverse_singly(sll))  # Output: [10, 30]

    # Doubly Linked List
    dll = ll.create_doubly_linked_list()
    ll.insert_doubly(dll, 100)
    ll.insert_doubly(dll, 200)
    ll.insert_doubly(dll, 300)
    print("Traverse Doubly after inserting nodes:", ll.traverse_doubly(dll))  # Output: [100, 200, 300]
    ll.delete_doubly(dll, 200)
    print("After delete:", ll.traverse_doubly(dll))  # Output: [100, 300]


    import stacks as st

    # Array-based Stack
    arr_stack = st.create_stack_array()
    st.push_array(arr_stack, 10)
    st.push_array(arr_stack, 20)
    print("Array Peek:", st.peek_array(arr_stack))  # Output: 20
    print("Array Pop:", st.pop_array(arr_stack))    # Output: 20
    print("Array Peek after pop:", st.peek_array(arr_stack))  # Output: 10

    # Linked List-based Stack
    ll_stack = st.create_stack_linked()
    st.push_linked(ll_stack, 100)
    st.push_linked(ll_stack, 200)
    print("Linked Peek:", st.peek_linked(ll_stack))  # Output: 200
    print("Linked Pop:", st.pop_linked(ll_stack))    # Output: 200
    print("Linked Peek after pop:", st.peek_linked(ll_stack))  # Output: 100


    import queues as q

    # Array-based Queue
    arr_q = q.create_queue_array()
    q.enqueue_array(arr_q, 10)
    q.enqueue_array(arr_q, 20)
    print("Array Front:", q.front_array(arr_q))     # Output: 10
    print("Array Dequeue:", q.dequeue_array(arr_q)) # Output: 10
    print("Array Front after dequeue:", q.front_array(arr_q))  # Output: 20

    # Linked List-based Queue
    ll_q = q.create_queue_linked()
    q.enqueue_linked(ll_q, 100)
    q.enqueue_linked(ll_q, 200)
    print("Linked Front:", q.front_linked(ll_q))     # Output: 100
    print("Linked Dequeue:", q.dequeue_linked(ll_q)) # Output: 100
    print("Linked Front after dequeue:", q.front_linked(ll_q)) # Output: 200


    import binary_tree as bt

    # Create tree and insert nodes
    root = None
    for value in [50, 30, 70, 20, 40, 60, 80]:
        root = bt.insert(root, value)

    print("In-order Traversal:")
    bt.inorder(root)  # 20 30 40 50 60 70 80

    print("
Pre-order Traversal:")
    bt.preorder(root)  # 50 30 20 40 70 60 80

    print("
Post-order Traversal:")
    bt.postorder(root)  # 20 40 30 60 80 70 50

    # Delete a node and show in-order
    root = bt.delete(root, 50)
    print("
In-order after deleting 50:")
    bt.inorder(root)  # 20 30 40 60 70 80


    import graph as g

    # Create graph and add vertices and edges
    graph = g.create_graph()
    g.add_edge(graph, 'A', 'B')
    g.add_edge(graph, 'A', 'C')
    g.add_edge(graph, 'B', 'D')
    g.add_edge(graph, 'C', 'D')
    g.add_edge(graph, 'C', 'E')

    print("DFS starting from A:")
    g.dfs(graph, 'A')  # A B D C E

    print("
BFS starting from A:")
    g.bfs(graph, 'A')  # A B C D E




