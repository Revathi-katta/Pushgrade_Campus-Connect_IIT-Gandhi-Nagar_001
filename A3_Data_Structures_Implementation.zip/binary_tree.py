
# Create a binary tree node
def create_node(data):
    return {"data": data, "left": None, "right": None}

# Insert a node into the binary tree (BST logic)
def insert(root, data):
    if root is None:
        return create_node(data)
    if data < root["data"]:
        root["left"] = insert(root["left"], data)
    else:
        root["right"] = insert(root["right"], data)
    return root

# Find minimum value node
def find_min(node):
    current = node
    while current and current["left"] is not None:
        current = current["left"]
    return current

# Delete a node from the binary tree
def delete(root, data):
    if root is None:
        return root
    if data < root["data"]:
        root["left"] = delete(root["left"], data)
    elif data > root["data"]:
        root["right"] = delete(root["right"], data)
    else:
        # Node found
        if root["left"] is None:
            return root["right"]
        elif root["right"] is None:
            return root["left"]
        temp = find_min(root["right"])
        root["data"] = temp["data"]
        root["right"] = delete(root["right"], temp["data"])
    return root

# In-order traversal: Left → Root → Right
def inorder(root):
    if root:
        inorder(root["left"])
        print(root["data"], end=" ")
        inorder(root["right"])

# Pre-order traversal: Root → Left → Right
def preorder(root):
    if root:
        print(root["data"], end=" ")
        preorder(root["left"])
        preorder(root["right"])

# Post-order traversal: Left → Right → Root
def postorder(root):
    if root:
        postorder(root["left"])
        postorder(root["right"])
        print(root["data"], end=" ")
