
import importlib
import floorplan_utils as fp
importlib.reload(fp)

print(fp.calculate_area(5.0, 3.2))
print(fp.classify_unit(2))
