
# Floor Plan Utilities

## Files:
- floorplan_utils.py
- main.py
- README.md

## How to run:
Install OpenCV with `pip install opencv-python`, then run `main.py`.

## Functions:
- `read_image(path)`: Reads an image.
- `calculate_area(l, w)`: Returns area.
- `classify_unit(n)`: Returns unit type like 2BHK.
