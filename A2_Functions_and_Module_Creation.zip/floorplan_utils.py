
import cv2
import numpy as np

def read_image(image_path):
    """
    Reads an image from the given path using OpenCV.

    Args:
        image_path (str): Path to the floor plan image.

    Returns:
        np.ndarray: The loaded image as a NumPy array.
    """
    image = cv2.imread(image_path, cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Image not found at {image_path}")
    return image

def calculate_area(length, width):
    """
    Calculates the area of a rectangular room.

    Args:
        length (float): Length of the room in meters.
        width (float): Width of the room in meters.

    Returns:
        float: Area in square meters.
    """
    return round(length * width, 2)

def classify_unit(num_bedrooms):
    """
    Classifies the unit type based on the number of bedrooms.

    Args:
        num_bedrooms (int): Number of bedrooms.

    Returns:
        str: Type of unit (e.g., '1BHK', '2BHK').
    """
    return f"{num_bedrooms}BHK"
